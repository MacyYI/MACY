mod bot;
mod residuals;
use crate::bot::Bot;
use fyrox::{
    core::{
        algebra::{Vector2, Vector3},
        pool::Handle,
        reflect::prelude::*,
        type_traits::prelude::*,
        visitor::prelude::*,
    },
    event::{ElementState, Event, WindowEvent},
    keyboard::{KeyCode, PhysicalKey},
    plugin::{Plugin, PluginContext, PluginRegistrationContext},
    scene::{
        animation::spritesheet::SpriteSheetAnimation,
        dim2::{rectangle::Rectangle, rigidbody::RigidBody},
        node::Node,
        Scene,
    },
    script::{ScriptContext, ScriptTrait},
};
use std::path::Path;
// ANCHOR_END: imports

#[derive(Visit, Reflect, Debug, Default)]
pub struct Game {
    scene: Handle<Scene>,
    player: Handle<Node>,
}

// ANCHOR: register
impl Plugin for Game {
    fn register(&self, context: PluginRegistrationContext) {
        let script_constructors = &context.serialization_context.script_constructors;
        script_constructors.add::<Player>("Player");
        script_constructors.add::<Bot>("Monsters");
    }

    fn init(&mut self, scene_path: Option<&str>, context: PluginContext) {
        context
            .async_scene_loader
            .request(scene_path.unwrap_or("data/scene.rgs"));
    }
    fn on_scene_loaded(
        &mut self,
        _path: &Path,
        scene: Handle<Scene>,
        _data: &[u8],
        context: &mut PluginContext,
    ) {
        if self.scene.is_some() {
            context.scenes.remove(self.scene);
        }
        self.scene = scene;
    }

    fn update(&mut self, context: &mut PluginContext) {
        if let Some(scene) = context.scenes.try_get_mut(self.scene) {
            scene.drawing_context.clear_lines();
        }
    }
}

#[derive(Visit, Reflect, Debug, Clone, TypeUuidProvider, ComponentProvider)]
#[type_uuid(id = "c5671d19-9f1a-4286-8486-add4ebaadaec")]
#[visit(optional)]
struct Player {
    sprite: Handle<Node>,
    move_left: bool,
    move_right: bool,
    jump: bool,
    attack1: bool,
    attack2: bool,
    attack3: bool,
    ddown: bool,
    health: i32,
    //添加动画
    animations: Vec<SpriteSheetAnimation>,
    current_animation: u32,
}
impl Default for Player {
    fn default() -> Self {
        Self {
            sprite: Handle::NONE,
            move_left: false,
            move_right: false,
            jump: false,
            attack1: false,
            attack2: false,
            attack3: false,
            ddown: false,
            health: 3,
            animations: Default::default(),
            current_animation: 0,
        }
    }
}
impl ScriptTrait for Player {
    fn on_init(&mut self, context: &mut ScriptContext) {}
    fn on_start(&mut self, ctx: &mut ScriptContext) {
        ctx.plugins.get_mut::<Game>().player = ctx.handle;
    }
    fn on_update(&mut self, context: &mut ScriptContext) {
        if let Some(rigid_body) = context.scene.graph[context.handle].cast_mut::<RigidBody>() {
            // 处理移动速度
            let x_speed = if self.move_left {
                1.5
            } else if self.move_right {
                -1.5
            } else {
                0.0
            };
            // 处理跳跃
            rigid_body.set_lin_vel(Vector2::new(x_speed, rigid_body.lin_vel().y));
            if self.jump {
                rigid_body.set_lin_vel(Vector2::new(x_speed, 3.0));
            }
            // 处理角色方向
            if let Some(sprite) = context.scene.graph.try_get_mut(self.sprite) {
                if x_speed != 0.0 {
                    let local_transform = sprite.local_transform_mut();
                    let current_scale = **local_transform.scale();
                    local_transform.set_scale(Vector3::new(
                        current_scale.x.copysign(-x_speed),
                        current_scale.y,
                        current_scale.z,
                    ));
                }
            }
            if x_speed != 0.0 {
                self.current_animation = 0;
            } else {
                self.current_animation = 1;
            }
            if self.attack1 {
                self.current_animation = 2;
            } 
            if self.attack2 {
                self.current_animation = 3;
            }
            if self.attack3 {
                self.current_animation = 4;
            } 
            if self.ddown {
                self.current_animation = 5;
            }
            if self.health==0{
                self.current_animation = 6;
            }
            println!("speed: {}",x_speed);
            // 更新动画
            if let Some(current_animation) =
                self.animations.get_mut(self.current_animation as usize)
            {
                current_animation.update(context.dt);

                if let Some(sprite) = context
                    .scene
                    .graph
                    .try_get_mut(self.sprite)
                    .and_then(|n| n.cast_mut::<Rectangle>())
                {
                    sprite
                        .material()
                        .data_ref()
                        .set_texture(&"diffuseTexture".into(), current_animation.texture())
                        .unwrap();
                    sprite.set_uv_rect(
                        current_animation
                            .current_frame_uv_rect()
                            .unwrap_or_default(),
                    );
                }
            }
        }
    }

    fn on_os_event(&mut self, event: &Event<()>, context: &mut ScriptContext) {
        if let Event::WindowEvent { event, .. } = event {
            if let WindowEvent::KeyboardInput { event, .. } = event {
                if let PhysicalKey::Code(keycode) = event.physical_key {
                    let is_pressed = event.state == ElementState::Pressed;
                    match keycode {
                        //设置结构体中的按键字段并输出按键信息
                        KeyCode::KeyA => {
                            self.move_left = is_pressed;
                            println!("Move left: {}", is_pressed);
                        }
                        KeyCode::KeyD => {
                            self.move_right = is_pressed;
                            println!("Move right: {}", is_pressed);
                        }
                        KeyCode::KeyW => {
                            self.jump = is_pressed;
                            println!("Jump: {}", is_pressed);
                        }
                        KeyCode::KeyU => {
                            self.attack1 = is_pressed;
                            println!("attack1: {}", is_pressed);
                        }
                        KeyCode::KeyI => {
                            self.attack2 = is_pressed;
                            println!("attack2: {}", is_pressed);
                        }
                        KeyCode::KeyO => {
                            self.attack3 = is_pressed;
                            println!("attack3: {}", is_pressed);
                        }
                        KeyCode::KeyS => {
                            self.ddown = is_pressed;
                            println!("down: {}", is_pressed);
                        }
                        _ => (),
                    }
                }
            }
        }
    }
}
