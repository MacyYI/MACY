## Android Build Instructions

- `cargo-apk apk run --target=armv7-linux-androideabi`

TODO: Add more detailed instructions.